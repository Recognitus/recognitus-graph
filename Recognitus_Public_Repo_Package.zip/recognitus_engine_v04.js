
// JavaScript logic from canvas inserted here manually.
// Please see the canvas for the latest working version.
