// [LOCK-FOCUS + INSIGHT PANEL]
import { useState, useEffect, useRef } from "react";

function generateGrammaton(node) {
  const base = "G";
  const entropyMark = Math.floor(node.entropy * 10);
  const recursionMark = node.recursionDepth.toString(16).toUpperCase();
  const contradictionMark = Math.floor(node.contradictionWeight * 9);
  return `${base}-${entropyMark}${recursionMark}${contradictionMark}`;
}

function interpretEntropy(e) {
  if (e > 0.95) return "Overloaded";
  if (e > 0.8) return "Volatile";
  if (e > 0.6) return "Shifting";
  return "Stable";
}

function interpretContradiction(c) {
  if (c > 0.7) return "Fractured";
  if (c > 0.4) return "Forked";
  if (c > 0.2) return "Layered";
  return "Linear";
}

function getLinkStrength(nodeA, nodeB) {
  const entropyDiff = Math.abs(nodeA.entropy - nodeB.entropy);
  const contradictionDiff = Math.abs(nodeA.contradictionWeight - nodeB.contradictionWeight);
  return 1 - (entropyDiff + contradictionDiff) / 2;
}

// [rest of the code is long – we can package it instead of printing it here]
