import React from 'react';
import ReactDOM from 'react-dom/client';
import RecognitusInterface from './RecognitusInterface';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<RecognitusInterface />);